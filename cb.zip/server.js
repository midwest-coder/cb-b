require('dotenv').config()

const express = require('express')
const app = express()
const cookieParser = require('cookie-parser')
app.use(cookieParser())
app.use(express.json())
const port = (process.env.PORT || 4000)
const http = require('http').createServer(app)
const io = require('socket.io')(http)
const mongoURL = 'mongodb+srv://grandmaster:rxE7JKk9tvlYJo1x@cluster0.s6u68.mongodb.net/cb?retryWrites=true&w=majority';
const test = 'mongodb://127.0.0.1/chatroom';

const mongoose = require('mongoose')

mongoose.connect(mongoURL, {useNewUrlParser: true}, () => {
    console.log('successfully connected to database')  
})


    const userRouter = require('./routes/User')
    app.use('/user', userRouter)

    http.listen(port, () => {
        console.log(`Listening on port ${port}...`)
    })